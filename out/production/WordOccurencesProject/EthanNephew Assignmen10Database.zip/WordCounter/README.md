# WordOccurrencesProject
Repo for UI assignment. 
Requires JavaFX

This program started as simply as an IDE ran application, but it has progressed to include a GUI and documentation. 
